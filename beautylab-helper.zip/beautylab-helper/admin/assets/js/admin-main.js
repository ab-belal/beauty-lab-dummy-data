(function ($) {
    "use strict";
    var wWidth = $(window).width();

    jQuery(document).ready(function ($) {
        var frame ;
        var gframe ;

        var img_url = $('#feaured_img_url').val();
        if( img_url ){
            $("#featured_img").attr('src', img_url);
        }

        var gallery_imgs_url = $('#gallery_imgs_url').val();
        gallery_imgs_url = gallery_imgs_url ? gallery_imgs_url.split(";") : Array();
        
        if( gallery_imgs_url ){
            for( var i in gallery_imgs_url ){
                var gallery_img_url = gallery_imgs_url[i];
                $("#gallery_imgs").append("<img src="+gallery_img_url+">");
            }
        }

        //---featured image----
        $('#upload_featured_img').on('click', function(){
            if(frame){
                frame.open();
                return false;
            }

            frame = wp.media({
                title: "Upload Image",
                button: {
                    text: "Insert Image"
                },
                multiple: false,
            });
            frame.on('select', function(){
                var attachment = frame.state().get('selection').first().toJSON();
                $("#feaured_img_id").val(attachment.id);
                $("#feaured_img_url").val(attachment.sizes.thumbnail.url);
                $("#featured_img").attr('src', attachment.sizes.thumbnail.url);
            });

            frame.open();

            return false;
        });

        //------gallery image-------
        $('#upload_gallery_imgs').on('click', function(){

            if(gframe){
                gframe.open();
                return false;
            }

            gframe = wp.media({
                title: "Upload Image",
                button: {
                    text: "Insert Image"
                },
                multiple: true
            });
            gframe.on('select', function(){
                var img_ids = [], 
                    img_urls = [], 
                    i;
                var attachments = gframe.state().get('selection').toJSON();
                $("#gallery_imgs").html('');
                
                for( i in attachments ){
                    var attachment = attachments[i];
                    img_ids.push(attachment.id);
                    img_urls.push(attachment.sizes.thumbnail.url);
                    $("#gallery_imgs").append("<img src="+attachment.sizes.thumbnail.url+">");

                }
                $("#gallery_imgs_id").val(img_ids.join(";"));
                $("#gallery_imgs_url").val(img_urls.join(";"));
            });

            gframe.open();

            return false;
        });
    });

    


}(jQuery));
