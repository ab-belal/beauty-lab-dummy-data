<?php
    
/**
 * Register service meta box(es).
 */

$flaticons = array( 
    'flaticon-spa' => __( 'Flaticon Spa', 'beauty-lab' ),
    'flaticon-lotus' => __( 'Flaticon Lotus', 'beauty-lab' ),
    'flaticon-lotus-1' => __( 'Flaticon Lotus-1', 'beauty-lab' ),
    'flaticon-hand-wash' => __( 'Flaticon Hand Wash', 'beauty-lab' ),
    'flaticon-hand-wash-1' => __( 'Flaticon Hand Wash-1', 'beauty-lab' ),
    'flaticon-medical' => __( 'Flaticon Medical', 'beauty-lab' ),
    'flaticon-medical-1' => __( 'Flaticon Medical-1', 'beauty-lab' ),
    'flaticon-reduce' => __( 'Flaticon Reduce', 'beauty-lab' ),
    'flaticon-hairdryer' => __( 'Flaticon Hairdryer', 'beauty-lab' ),
    'flaticon-nature' => __( 'Flaticon Nature', 'beauty-lab' ),
    'flaticon-bath' => __( 'Flaticon Bath', 'beauty-lab' ),
    'flaticon-relax' => __( 'Flaticon Relax', 'beauty-lab' ),
    'flaticon-relax-1' => __( 'Flaticon Relax-1', 'beauty-lab' ),
    'flaticon-graduate-diploma' => __( 'Flaticon Graduate Diploma', 'beauty-lab' ),
    'flaticon-planning' => __( 'Flaticon Planning', 'beauty-lab' ),
    'flaticon-calendar-with-day-off' => __( 'Flaticon Calendar With Day off', 'beauty-lab' ),
    'flaticon-wall-calendar-with-lines' => __( 'Flaticon Wall Calendar with lines', 'beauty-lab' ),
    'flaticon-weekly-calendar' => __( 'Flaticon Weekly Calendar', 'beauty-lab' ),
    'flaticon-monthly-calendar' => __( 'Flaticon Monthly Calendar', 'beauty-lab' ),
    'flaticon-school-calendar' => __( 'Flaticon School Calendar', 'beauty-lab' ),
    'flaticon-flask' => __( 'Flaticon Flask', 'beauty-lab' ),
    'flaticon-health-care' => __( 'Flaticon Health Care', 'beauty-lab' ),
    'flaticon-nurse' => __( 'Flaticon Nurse', 'beauty-lab' ),
);

//---check nonce----
function is_nonce_secured( $nonce_field, $nonce_action, $post_id){
    $nonce = isset($_POST[$nonce_field]) ? $_POST[$nonce_field] : '';

    if($nonce == ''){
        return false;
    }
    if(!wp_verify_nonce( $nonce, $nonce_action )){
        return false;
    }
    if(!current_user_can( 'edit_post', $post_id )){
        return false;
    }
    if( wp_is_post_autosave( $post_id ) ){
        return false;
    }
    if( wp_is_post_revision( $post_id ) ) {
        return false;
    }

    return true;
}


function beautylab_helper_service_metaboxes_register() {
    add_meta_box( 'beauty-service-metabox', __( 'Service Informations', 'beautylab-helper' ), 'beautylab_helper_service_metaboxes_display', 'beauty-service', 'normal', 'high' );
}
add_action( 'add_meta_boxes', 'beautylab_helper_service_metaboxes_register' );


/**
 * Display metaboxes
 */
function beautylab_helper_service_metaboxes_display( $post ){
    wp_nonce_field( 'beautylab_helper_service_nonce_action', 'beautylab_helper_service_nonce' );

    global $flaticons;

    $staffs = get_terms( array(
        'taxonomy' => 'staff',
        'hide_empty' => false,
    ) );

    $service_icon = get_post_meta($post->ID, 'beauty-service-icon', true);
    $beauty_staff = get_post_meta($post->ID, 'beauty-service-staff', true);
    $price        = get_post_meta($post->ID, 'price', true);
    $duration     = get_post_meta($post->ID, 'duration', true);
    $hotline      = get_post_meta($post->ID, 'hotline', true);
    $schedule     = get_post_meta($post->ID, 'schedule', true);
    $short_description = get_post_meta($post->ID, 'short-description', true);
    //$brochure     = get_post_meta($post->ID, 'brochure', true);
    
    $html = '';
    $html.='<div class="beauty-service-metaboxes">';
        $html.='<div class="form-field beauty-service-icon">';
            $html.='<label>'.__('Service Icon ', 'beautylab-helper').'</label>';
            $html .= '<select name="beauty-service-icon">';
                $html .= '<option value="">'.__('Select Icon', 'beautylab-helper').'</option>';
                foreach( $flaticons as $key => $flaticon ){
                    $selected = '';
                    if ( $key == $service_icon ){
                        $selected = 'selected';
                    }
                    $html .= '<option value="'.$key.'" '.$selected.'>'.$flaticon.'</option>';
                }
            $html .= '</select>';
        $html.='</div>';

        $html.='<div class="form-field beauty-staff">';
            $html.='<label>'.__('Staff ', 'beautylab-helper').'</label>';
            $html .= '<select name="beauty-service-staff">';
                $html .= '<option value="">'.__('Select Staff', 'beautylab-helper').'</option>';
                foreach( $staffs as $staff ){
                    $selected = '';
                    if ( $staff->name == $beauty_staff ){
                        $selected = 'selected';
                    }
                    $html .= '<option value="'.$staff->name.'" '.$selected.'>'.$staff->name.'</option>';
                }
            $html .= '</select>';
        $html.='</div>';

        $html.='<div class="form-field price">';
            $html.='<label for="price">'.__('Price ', 'beautylab-helper').'</label>';
            $html.='<input name="price" id="price" type="text" placeholder="e.g. $70" value="'.$price.'">';
        $html.='</div>';

        $html.='<div class="form-field duration">';
            $html.='<label for="duration">'.__('Duration ', 'beautylab-helper').'</label>';
            $html.='<input name="duration" id="duration" type="text" placeholder="e.g. 1.3 Hour" value="'.$duration.'">';
        $html.='</div>';

        $html.='<div class="form-field hotline">';
            $html.='<label for="hotline">'.__('Hotline ', 'beautylab-helper').'</label>';
            $html.='<input name="hotline" id="hotline" type="text" value="'.$hotline.'">';
        $html.='</div>';

        $html.='<div class="form-field schedule">';
            $html.='<label for="schedule">'.__('Opening Schedule ', 'beautylab-helper').'</label>';
            $html.='<input name="schedule" id="schedule" type="text" placeholder="e.g. Mon - Fri : 09:00 - 18:00" value="'.$schedule.'">';
        $html.='</div>';
        
        $html.='<div class="form-field short-description">';
            $html.='<label for="short-description">'.__('Short Description', 'beautylab-helper').'</label>';
            $html.='<textarea name="short-description" id="short-description" rows="3">'.$short_description.'</textarea>';
        $html.='</div>';

        // $html.='<div class="form-field brochure">';
        //     $html.='<label for="brochure">'.__('Add File ', 'beautylab-helper').'</label>';
        //     $html.='<input name="brochure" id="brochure" type="file" value="'.$brochure.'" >';
        // $html.='</div>';
    $html.='</div>';

    echo $html;

}


/**
 * Save metaboxes
 */
add_action('save_post', 'beautylab_helper_service_metaboxes_save');

function beautylab_helper_service_metaboxes_save( $post_id ){
    if( !is_nonce_secured('beautylab_helper_service_nonce', 'beautylab_helper_service_nonce_action', $post_id) ){
        return $post_id;
    }

    $service_icon = isset($_POST['beauty-service-icon']) ? $_POST['beauty-service-icon'] : array();
    $beauty_staff = isset($_POST['beauty-service-staff']) ? $_POST['beauty-service-staff'] : array();
    $price        = isset($_POST['price']) ? $_POST['price'] : '';
    $duration     = isset($_POST['duration']) ? $_POST['duration'] : '';
    $hotline      = isset($_POST['hotline']) ? $_POST['hotline'] : '';
    $schedule     = isset($_POST['schedule']) ? $_POST['schedule'] : '';
    $short_description = isset($_POST['short-description']) ? $_POST['short-description'] : '';
    //$brochure     = isset($_POST['brochure']) ? $_POST['brochure'] : '';

    update_post_meta($post_id, 'beauty-service-icon', $service_icon);
    update_post_meta($post_id, 'beauty-service-staff', $beauty_staff);
    update_post_meta($post_id, 'price', $price);
    update_post_meta($post_id, 'duration', $duration);
    update_post_meta($post_id, 'hotline', $hotline);
    update_post_meta($post_id, 'schedule', $schedule);
    update_post_meta($post_id, 'short-description', $short_description);
   // update_post_meta($post_id, 'brochure', $brochure);
    
}

?>