<?php
/**
 * Plugin Name: Beauty Lab Helper
 * Description: Beauty lab theme helper functionaliy
 * Plugin URI:  
 * Author:      Themecon
 * Author URI:  themecon.net
 * License:     GPL v2 or later
 * Version:     1.0.0
 * Text Domain: beautylab-helper
 */

 // Exit if accessed directly
defined( 'ABSPATH' ) || exit;
define("ADMIN_ASSETS_DIR", plugin_dir_url(__FILE__)."admin/assets");

/**
 * Post Type: Services.
 */

function beautylab_helper_cpt_beauty_service() {
	$labels = [
		"name" => __( "Services", "beautylab-helper" ),
		"singular_name" => __( "Service", "beautylab-helper" ),
		"menu_name" => __( "Services", "beautylab-helper" ),
		"all_items" => __( "All Services", "beautylab-helper" ),
		"add_new_item" => __( "Add New Service", "beautylab-helper" ),
		"edit_item" => __( "Edit Service", "beautylab-helper" ),
		"view_item" => __( "View Service", "beautylab-helper" ),
	];

	$args = [
		"label" => __( "Services", "beautylab-helper" ),
		"labels" => $labels,
		"description" => "",
		"public" => true,
		"publicly_queryable" => true,
		"show_ui" => true,
		"show_in_rest" => true,
		"rest_base" => "",
		"rest_controller_class" => "WP_REST_Posts_Controller",
		"has_archive" => "services",
		"show_in_menu" => true,
		"show_in_nav_menus" => true,
		"delete_with_user" => false,
		"exclude_from_search" => false,
		"capability_type" => "post",
		"map_meta_cap" => true,
		"hierarchical" => false,
		"rewrite" => [ "slug" => "services", "with_front" => true ],
		"query_var" => true,
		"menu_position" => 20,
		"menu_icon" => "dashicons-shield",
		"supports" => [ "title", "editor", "thumbnail", "excerpt", "custom-fields", "page-attributes" ],
		"taxonomies" => [ "category", "post_tag" ],
	];

	register_post_type( "beauty-service", $args );
}

add_action( 'init', 'beautylab_helper_cpt_beauty_service' );



/**
 * Taxonomy: Staff.
 */
function beautylab_helper_my_staffs() {
	$labels = [
		"name" => __( "Staffs", "beautylab-helper" ),
		"singular_name" => __( "staff", "beautylab-helper" ),
		"all_items" => __( "All Staffs", "beautylab-helper" ),
		"edit_item" => __( "Edit Staff", "beautylab-helper" ),
		"view_item" => __( "View Staff", "beautylab-helper" ),
		"update_item" => __( "Update Staff", "beautylab-helper" ),
		"add_new_item" => __( "Add New Staff", "beautylab-helper" ),
	];

	$args = [
		"label" => __( "Staffs", "beautylab-helper" ),
		"labels" => $labels,
		"public" => true,
		"publicly_queryable" => true,
		"hierarchical" => false,
		"show_ui" => true,
		"show_in_menu" => true,
		"show_in_nav_menus" => true,
		"query_var" => true,
		"rewrite" => [ 'slug' => 'staff', 'with_front' => true, ],
		"show_admin_column" => true,
		"show_in_rest" => true,
		"rest_base" => "staff",
		"rest_controller_class" => "WP_REST_Terms_Controller",
		"show_in_quick_edit" => false,
			];
	register_taxonomy( "staff", [ "beauty-service" ], $args );
}
add_action( 'init', 'beautylab_helper_my_staffs' );


//--metabox register for staff---
function beautylab_helper_staff_designation(){
    $args = array(
        'type' => 'string',
        'sanitize_callback' => 'sanitize_text_field',
        'single' => true,
        'discription' => 'Staff Designation',
    );

    register_meta( 'term', 'beauty_staff_designation', $args );
}
add_action( 'init', 'beautylab_helper_staff_designation' );

//--add staff designation input field---
function beautylab_helper_staff_designation_field(){
    $html = '';
    $html.='<div class="form-field term-name-wrap">';
        $html.='<label for="staff-designation">'.__('Designation', 'beautylab-helper').'</label>';
        $html.='<input name="staff-designation" id="staff-designation" type="text" value="">';
    $html.='</div>';

    echo $html;
}
add_action( 'staff_add_form_fields', 'beautylab_helper_staff_designation_field' );

//--edit staff designation input field---
function beautylab_helper_staff_designation_edit_field( $term ){
    $staff_designation = get_term_meta( $term->term_id, 'beauty_staff_designation', true );

    $html = '';
    $html.='<tr class="form-field term-name-wrap">';
        $html.='<th scope="row"><label for="staff-designation">'.__('Designation', 'beautylab-helper').'</label></th>';
        $html.='<td><input name="staff-designation" id="staff-designation" type="text" value="'.$staff_designation.'">';
    $html.='</tr>';

    echo $html;
}
add_action( 'staff_edit_form_fields', 'beautylab_helper_staff_designation_edit_field' );

//--save staff designation input value---
function beautylab_helper_staff_designation_save( $term_id ){
	$staff_designation = "";
	
    if( isset( $_POST['_wpnonce_add-tag'] ) && wp_verify_nonce( $_POST['_wpnonce_add-tag'], 'add-tag' ) ){
        $staff_designation = sanitize_text_field( $_POST['staff-designation'] );
    }
    update_term_meta( $term_id, 'beauty_staff_designation', $staff_designation );
}
add_action( 'create_staff', 'beautylab_helper_staff_designation_save' );

//--edit staff designation input value---
function beautylab_helper_staff_designation_edit( $term_id ){
	$staff_designation = "";

    if( wp_verify_nonce( $_POST['_wpnonce'], 'update-tag_'.$term_id ) ){
        $staff_designation = sanitize_text_field( $_POST['staff-designation'] );
    }
    update_term_meta( $term_id, 'beauty_staff_designation', $staff_designation );
}
add_action( 'edit_staff', 'beautylab_helper_staff_designation_edit' );


//----add designation column on staff term table----
if(!function_exists('beautylab_helper_add_terms_table_column')){
    function beautylab_helper_add_terms_table_column( $columns ){
		$columns['designation'] = __('Designation', 'beautylab-helper');

		return $columns;
	}
	add_filter('manage_edit-staff_columns' , 'beautylab_helper_add_terms_table_column');
}

//----add designation column content on staff term table----
if(!function_exists('beautylab_helper_add_terms_table_column_content')){
    function beautylab_helper_add_terms_table_column_content( $content, $column_name, $term_id ){
		$terms = get_term_meta($term_id, 'beauty_staff_designation');

		if ( 'designation' == $column_name ) {
			$content = $terms[0];
		}
		return $content;
	}
	add_filter( 'manage_staff_custom_column', 'beautylab_helper_add_terms_table_column_content', 10, 3 );
}


//---admin enqueue script----
function beautylab_helper_service_admin_script(){
	wp_enqueue_style( 'service-meta-style', ADMIN_ASSETS_DIR."/css/service-meta-style.css", false, '1.1', 'all');
	//wp_enqueue_script('admin-main', ADMIN_ASSETS_DIR."/js/admin-main.js", array('jquery'), '1.0', true);
}
add_action( 'admin_enqueue_scripts', 'beautylab_helper_service_admin_script' );

/**
 * service informations metabox
 */
require plugin_dir_path( __FILE__ ) . 'service-metaboxes.php';